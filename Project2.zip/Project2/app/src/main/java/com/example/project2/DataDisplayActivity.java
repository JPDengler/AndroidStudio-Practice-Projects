package com.example.project2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DataDisplayActivity extends AppCompatActivity {

    private GridLayout dataGrid;
    private Button btnAddData;
    private int itemCount = 2; // Starting from 2 since we have two initial items

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dataGrid = findViewById(R.id.data_grid);
        btnAddData = findViewById(R.id.btn_add_data);

        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });
    }

    private void addData() {
        TextView newItem = new TextView(this);
        newItem.setText("Item " + (++itemCount));
        newItem.setPadding(8, 8, 8, 8);

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1);
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1);
        newItem.setLayoutParams(params);

        dataGrid.addView(newItem);
    }
}