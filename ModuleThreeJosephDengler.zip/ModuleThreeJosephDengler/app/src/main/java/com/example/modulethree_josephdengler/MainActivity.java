package com.example.modulethree_josephdengler;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

// Handles main user interface and interaction with 'Say Hello' button
public class MainActivity extends AppCompatActivity {
    // UI elements
    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    // Called when the activity is first created
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello.setEnabled(false);

        // TextWactcher to enable/disable the button
        nameText.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                // No action
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
                // No action
            public void afterTextChanged(android.text.Editable s) {
                // Enable button if not empty
                buttonSayHello.setEnabled(!s.toString().isEmpty());
            }
        });
    }

    // Handles button being clicked
    public void SayHello(View view) {
        String name = nameText.getText().toString();
        if (!name.isEmpty()) {
            textGreeting.setText("Hello, " + name);
        }
    }
}