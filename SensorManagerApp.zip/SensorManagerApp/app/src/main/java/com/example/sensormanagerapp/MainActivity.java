package com.example.sensormanagerapp;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {

    private TextView sensorData;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sensorData = new TextView(this);
        setContentView(sensorData);

        // Initialize SensorManager and Accelerometer as local variables
        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void onSensorChanged(SensorEvent event) {
        // Get accelerometer values
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        // Update the TextView with sensor data
        sensorData.setText("Accelerometer Data:\nX: " + x + "\nY: " + y + "\nZ: " + z);
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // This method is required by the SensorEventListener interface but is not used here.
    }
}